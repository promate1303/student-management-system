<?php 
    $con = mysqli_connect('localhost','root','','sms') or die ('I cannot connect to the datebase because: ' . mysql_error());;
    if($con == false)
        {echo "Not Connected";}
    else
    {echo "";}
?>