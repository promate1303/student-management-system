<?php
    session_start();
    if(isset($_SESSION['uid']))
    {
        header('location: admin/admindash.php');
    }

?>

<html>
    <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <style>
            body {font-family: Arial, Helvetica, sans-serif;}
            .cont
            {
                padding: 10px 25px 10px 25px;
                margin: 0px 25px 10px 25px;
                border: 3px solid #f1f1f1;
                
            }
        </style>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="file.css">
    </head>
    <body style="background-image: linear-gradient(to right, #f83600 0%, #f9d423 100%);">

    <ul>
        <li style="float:left" class="active"><a href="home.php">Back</a></li>
    </ul>

    <div style="padding: 0px 0px 20px 0px" align="center"><font size="50px">
        Admin Log-in page</font>
    </div>

    <form action="login.php" method="post">
    <div style="background-color:grey;" class="cont">
        <div class="imgcontainer"   align:center;>
            <img src="images/avatar2.png" alt="Avatar" class="avatar">
        </div>
        <div class="container">
            <label for="uname"><b>Username</b></label>
            <input type="text" placeholder="Enter Username" name="uname" required>

            <label for="psw"><b>Password</b></label>
            <input type="password" placeholder="Enter Password" name="psw" required>
                
            <button type="login" name="login">Login</button>
            <label>
        </div>
    </div>
    </form>
</body>
</html>

<?php 
    include("dbcon.php");
    if(isset($_POST['login']))
    {
        $username = $_POST['uname'];
        $password = $_POST['psw'];

        $query = "SELECT * FROM `admin` WHERE `username`='$username' AND`password`='$password'";
        $run = mysqli_query($con,$query);
        $row = mysqli_num_rows($run);
        if($row < 1)
        {
?>
            <script>
                alert('Username or Password not matched!!');
                window.open('login.php','_self');
            </script>
<?php
        }
        else
        {
            $data = mysqli_fetch_assoc($run);
            $id = $data['id'];
            $_SESSION['uid']=$id;
            header('location:admin/admindash.php');
        }
    }

?>

