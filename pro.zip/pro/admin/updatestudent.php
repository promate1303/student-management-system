<?php
    include("../dbcon.php");
    session_start();
    if(isset($_SESSION['uid']))
    {echo "";}
    else
    {header('location: ../login.php');}    
?>

<!DOCTYPE html>
<html>
<head>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <style>
        ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: #333;
        }
        li {float: left;}

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 30px;
            text-decoration: none;
        }

        li a:hover:not(.active) {background-color: white;}

        .active
        {
            background-color: #4CAF50;
        }

        /*search box css start here*/
        .search-sec{
            padding: 2rem;
        }
        .search-slt{
            display: block;
            width: 100%;
            font-size: 16px;
            line-height: 1.5;
            color: #55595c;
            background-color: #fff;
            background-image: none;
            border: 1px solid #ccc;
            height: calc(3rem + 20px) !important;
            border-radius:1;
        }
        .wrn-btn{
            width: 100%;
            font-size: 20px;
            font-weight: 400;
            text-transform: capitalize;
            height: calc(3rem + 20px) !important;
            border-radius:1;
        }
        @media (min-width: 992px){
            .search-sec{
                background: rgba(26, 70, 124, 0.41);
            }
        }

        @media (max-width: 992px){
            .search-sec{
                background: #1A4668;
            }
        }

        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid black;
        }

        th, td {
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even){background-color: #f2f2f2}

        th {
            background-color: #4CAF50;
            color: white;
        }
        
        tr:hover {background-color: #f5f5f5;}
    </style>
    <title>Student Management System</title>
</head>
<body style="background-image: linear-gradient(to right, #f83600 0%, #f9d423 100%);">
    <ul>
        <li style="float:left" class="active"><a href="admindash.php">Back</a></li>
        <li style="float:right" class="active"><a href="deletestudent.php">Delete</a></li>
        <li style="float:right" class="active"><a href="addstudent.php">Add</a></li>
    </ul>
    <font size="3">
        <div style="padding: 20px 0px 20px 0px" align="center"><font size="50px">
            UPDATE the Data of the Student's</font>
        </div>

    <section class="search-sec">
        <div class="container" style="padding-left:70px">
            <form action="#" method="post" novalidate="novalidate">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                                <input type="text" class="form-control search-slt" placeholder="Enter Standard" name="std">
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                                <input type="text" class="form-control search-slt" placeholder="Enter Name" name="name">
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                                <input type="text" class="form-control search-slt" placeholder="Enter City" name="city">
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 p-0">
                                <button type="submit" class="btn btn-danger wrn-btn" name="submit">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    </font>

</body>
</html>

<table border="1px solid">
  <tr>
    <th>Edit</th>
    <th>id</th>
    <th>Roll-no</th>
    <th>Name</th>
    <th>City</th>
    <th>Parents Contact</th>
    <th>Standart</th>
    <th>Image</th>
  </tr>

<?php
    if(isset($_POST['submit']))
    {
        $std=$_POST['std'];
        $name=$_POST['name'];
        $city=$_POST['city'];
        $query="SELECT * FROM `student` WHERE `std`='$std' AND `name` LIKE '%$name%' AND `city` LIKE '%$city%'";
        $run = mysqli_query($con,$query);
        if(mysqli_num_rows($run)<1)
        {
            echo "<tr><td colspan='8'> NO Record's found </td></tr>";
        }
        else
        {
            while($data = mysqli_fetch_assoc($run))
            {
?>
                <tr>
                    <td><a href="updateform.php?sid=<?php echo $data['id']; ?>">Edit</a></td>
                    <td><?php echo $data['id']; ?></td>
                    <td><?php echo $data['rollno']; ?></td>
                    <td><?php echo $data['name']; ?></td>
                    <td><?php echo $data['city']; ?></td>
                    <td><?php echo $data['pcont']; ?></td>
                    <td><?php echo $data['std']; ?></td>
                    <td><img src="../dataimg/<?php echo $data['image']; ?>"  style="max-width:100px;" /></td>
                </tr>
<?php
            }
        }
    }
?>
</table>