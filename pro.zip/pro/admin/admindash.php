<?php
    include("../dbcon.php");
    session_start();
    if(isset($_SESSION['uid']))
    {echo "";}
    else
    {header('location: ../login.php');}    
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Management System</title>
  <link rel="stylesheet" type="text/css" href="../file.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body style="background-image: linear-gradient(to right, #f83600 0%, #f9d423 100%);">
    <ul>
        <li style="float:right" class="active"><a href="/pro/logout.php">Logout</a></li>
    </ul> 
<div class="container">
  <div style="font-size:70px" align="center">
    Welcome To Admin DashBoard
  </div>
    <div class="panel-group">

    <div style="padding:30px">
    <div class="panel panel-success">
      <div class="panel-heading">ADD New Student Details</div>
      <div class="panel-body"><a href="addstudent.php">ADD</a></div>
    </div>
    </div>

    <div style="padding:30px">
    <div class="panel panel-info">
      <div class="panel-heading">UPDATE Student Details</div>
      <div class="panel-body"><a href="updatestudent.php">UPDATE</a></div>
    </div>
    </div>

    <div style="padding:30px">
    <div class="panel panel-danger">
      <div class="panel-heading">DELETE Student Details</div>
      <div class="panel-body"><a href="deletestudent.php">DELETE</a></div>
    </div>
  </div>
  </div>
</div>

</body>
</html>

