<?php
    include("../dbcon.php");
    session_start();
    if(isset($_SESSION['uid']))
    {echo "";}
    else
    {header('location: ../login.php');}
    $sid=$_GET['sid'];
    $query = "SELECT * FROM `student` WHERE `id`='$sid'";
    $run=mysqli_query($con,$query);
    $data=mysqli_fetch_assoc($run);   
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 5px 25px 10px 25px;
  width: 98%;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        background-color: #333;
        }
    li {float: left;}

    li a {
        display: block;
        color: white;
        text-align: center;
        padding: 14px 30px;
        text-decoration: none;
    }

    li a:hover:not(.active) {background-color: white;}

    .active
    {
        background-color: #4CAF50;
    }

</style>
  <title>Student Management System</title>

</head>
<body style="background-image: linear-gradient(to right, #f83600 0%, #f9d423 100%);">
    <ul>
        <li style="float:left" class="<input type="submit" name="submit" value="Submit" >active"><a href="updatestudent.php">Back</a></li>
        <li style="float:right" class=<input type="submit" name="submit" value="Submit" >"active"><a href="deletestudent.php">Delete</a></li>
        <li style="float:right" class=<input type="submit" name="submit" value="Submit" >"active"><a href="addstudent.php">Add</a></li>
    </ul>
    <font size="3">
    <div style="padding: 20px 0px 40px 0px" align="center"><font size="50px">
        UPDATE the Data of the Student</font>
    </div>
    <form method="post" action="#" enctype="multipart/form-data">
        <div class="container">
            <div class="row">
                <div class="col-25">
                    <label for="fname">Roll-no</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="rollno" value=<?php echo $data['rollno'] ?> required>
                </div>
            </div>
            <div class="row">
                <div class="col-25">        
                    <label for="lname">Name</label>
                </div>

                <div class="col-75">
                    <input type="text" id="lname" name="name" value=<?php echo $data['name'] ?> required>
                </div>
            </div>
            <div class="row">
                <div class="col-25">
                    <label for="fname">City</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="city" value=<?php echo $data['city'] ?> required>
                </div>
            </div>
            <div class="row">
                <div class="col-25">
                    <label for="fname">Parent's contact no</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="pcont" value=<?php echo $data['pcont'] ?> required>
                </div>
            </div>
            <div class="row">
                <div class="col-25">
                    <label for="fname">Standard</label>
                </div>
                <div class="col-75">
                    <input type="text" id="fname" name="std" value=<?php echo $data['std'] ?> required>
                </div>
            </div>
            <div class="row" style="padding-top:10px">
                <input type="hidden" name="sid" value="<?php echo $data['id'] ?>" >
                <input type="submit" name="submit" value="Submit" >
            </div>
        </div>
    </form>
</body>
</html>

<?php
if(isset($_POST['submit']))
{
    $roll = $_POST['rollno'];
    $name = $_POST['name'];
    $city = $_POST['city'];
    $pcont = $_POST['pcont'];
    $std = $_POST['std'];
    $id=$_POST['sid'];
    $query = "UPDATE `student` SET `id`= '$id',`rollno`='$roll',`name`='$name',`city`='$city',`pcont`='$pcont',`std`='$std' WHERE `id`= $id";
    $run = mysqli_query($con,$query);
    if($run == TRUE)
    {  
?>
        <script>
            alert('Data updated Successfully.');
            window.open('updatestudent.php','_self');
        </script>

<?php

    }
    header('location:updatestudent.php');
}
?>